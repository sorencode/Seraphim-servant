const fs = require('fs');
const path = require('path');
const { logSuccess, logError } = require('../utils/logger');

module.exports = (client) => {
    const eventsPath = path.join(__dirname, '..', 'events');
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        try {
            const filePath = path.join(eventsPath, file);
            const event = require(filePath);

            if (event.once) {
                client.once(event.name, (...args) => event.execute(...args, client));
            } else {
                client.on(event.name, (...args) => event.execute(...args, client));
            }
            logSuccess(`Loaded Event: ${file}`);
        } catch (error) {
            logError(`Failed to load event ${file}: ${error.message}`);
        }
    }
};
